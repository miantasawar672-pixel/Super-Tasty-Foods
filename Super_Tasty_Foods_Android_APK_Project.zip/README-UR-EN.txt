# Super Tasty Foods Ads — Android APK project (free)

This wraps the existing HTML dashboard in an Android WebView app.

## Important
- This ZIP is Android source code, **not a ready-to-install APK**.
- The current environment does not have Android SDK/Gradle installed, so it cannot compile the APK here.
- The app uses the dashboard's local browser storage and WhatsApp share links. It does not connect to WhatsApp Business API and does not send bulk messages automatically.
- Customer/campaign data is stored locally on the device; it is not cloud-synced.

## Build a free APK using GitHub Actions
1. Create/sign in to a GitHub account.
2. Create a new repository and upload all files from this ZIP.
3. Open the repository's **Actions** tab.
4. Run **Build Super Tasty Foods APK** (or push to `main`).
5. Open the completed workflow run and download the artifact named `Super-Tasty-Foods-APK`.
6. Extract the downloaded artifact to get `app-debug.apk`, then transfer it to your Android phone and install it.

## Build locally
Open this folder in Android Studio with Android SDK 35 installed, then build the app's debug APK.

Package: `com.supertastyfoods.ads`
App label: `Super Tasty Foods Ads`
